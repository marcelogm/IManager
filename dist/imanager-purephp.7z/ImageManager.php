<?php
namespace App\Plugins;
use Pure\Bases\Plugin;

/**
 * Classe de apoio para upload de imagem
 *
 * @version 1.0
 * @author Marcelo Gomes Martins
 */
class ImageManager extends Plugin
{

	function source()
	{
		return [
			'namespace' => 'IManager',
			'class' => 'IMPlugin'
		];
	}

}